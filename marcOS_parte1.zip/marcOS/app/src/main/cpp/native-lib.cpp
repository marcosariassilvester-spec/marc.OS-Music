#include <jni.h>
#include "AudioEngine.h"
static AudioEngine E;
#define FN(ret, name) extern "C" JNIEXPORT ret JNICALL Java_com_marc_os_NativeAudio_##name
FN(jboolean, start)(JNIEnv *, jobject) { return E.start(); }
FN(void, stop)(JNIEnv *, jobject) { E.stop(); }
FN(void, noteOn)(JNIEnv *, jobject, jint id, jint midi, jfloat vel) { E.noteOn(id, midi, vel); }
FN(void, noteOff)(JNIEnv *, jobject, jint id) { E.noteOff(id); }
FN(void, drum)(JNIEnv *, jobject, jint idx, jfloat vel) { E.drum(idx, vel); }
FN(void, setParam)(JNIEnv *, jobject, jint i, jfloat v) { E.setParam(i, v); }
FN(void, setPlaying)(JNIEnv *, jobject, jboolean p) { E.setPlaying(p); }
FN(void, setCell)(JNIEnv *, jobject, jint l, jint s, jboolean on) { E.setCell(l, s, on); }
FN(void, clearPattern)(JNIEnv *, jobject) { E.clearPattern(); }
FN(void, setLaneNote)(JNIEnv *, jobject, jint l, jint m) { E.setLaneNote(l, m); }
FN(jint, getStep)(JNIEnv *, jobject) { return E.step(); }
FN(jfloat, getLatencyMs)(JNIEnv *, jobject) { return E.latencyMs(); }
FN(void, setBursts)(JNIEnv *, jobject, jint n) { E.setBursts(n); }
