#include "AudioEngine.h"
#include <cmath>
#include <algorithm>

static const float TWO_PI = 6.2831853f;
struct DP { float f0, f1, pd, dec, tone, noise, hp; };
static const DP DT[16] = {
    {150, 45, 25, 7.5f, 1, 0, 0},   {200, 55, 35, 14, 1, 0, 0},     {220, 150, 25, 18, .6f, .8f, .7f}, {0, 0, 0, 22, 0, 1, .55f},
    {0, 0, 0, 45, 0, 1, .85f},      {0, 0, 0, 9, 0, 1, .85f},       {800, 600, 40, 60, .7f, .2f, .5f}, {560, 540, 5, 10, 1, 0, 0},
    {120, 70, 25, 9, 1, 0, 0},      {180, 100, 25, 10, 1, 0, 0},    {260, 150, 25, 11, 1, 0, 0},       {0, 0, 0, 3, 0, 1, .8f},
    {1200, 900, 30, 30, 1, 0, 0},   {330, 250, 25, 14, 1, 0, 0},    {0, 0, 0, 25, 0, 1, .7f},          {2000, 100, 12, 8, 1, 0, 0}};

AudioEngine::AudioEngine() {
    const float d[12] = {.8f, .8f, .15f, 0.f, .3f, .15f, .5f, 0.f, 110.f, 16.f, 0, 0};
    for (int i = 0; i < 12; i++) P[i].store(d[i]);
    for (auto &p : pat) p.store(0);
    for (auto &n : laneNote) n.store(48);
}

void AudioEngine::push(uint8_t t, int a, int b, float v) {
    uint32_t w = wr.load(std::memory_order_relaxed);
    if (w - rd.load(std::memory_order_acquire) >= (uint32_t)RN) return;
    Ev e; e.type = t; e.a = (uint8_t)a; e.b = (uint8_t)b; e.v = v;
    ring[w % RN] = e;
    wr.store(w + 1, std::memory_order_release);
}

void AudioEngine::setCell(int lane, int step, bool on) {
    if (lane < 0 || lane > 31 || step < 0 || step > 31) return;
    if (on) pat[lane].fetch_or(1u << step); else pat[lane].fetch_and(~(1u << step));
}

float AudioEngine::noise() { rng ^= rng << 13; rng ^= rng >> 17; rng ^= rng << 5; return rng * (1.f / 2147483648.f) - 1.f; }

void AudioEngine::noteOnI(int id, int midi, float vel, int gate) {
    Synth *v = &syn[0];
    for (auto &s : syn) { if (!s.on) { v = &s; break; } if (s.env < v->env) v = &s; }
    *v = Synth();
    v->on = true; v->id = id; v->vel = vel; v->gate = gate;
    v->freq = 440.f * std::pow(2.f, (midi - 69) / 12.f);
}

void AudioEngine::drumI(int idx, float vel) {
    if (idx < 0 || idx > 15) return;
    Drum *d = &dr[0];
    for (auto &x : dr) { if (!x.on) { d = &x; break; } if (x.n > d->n) d = &x; }
    *d = Drum(); d->on = true; d->type = idx; d->vel = vel;
}

bool AudioEngine::start() {
    wanted = true;
    oboe::AudioStreamBuilder b;
    b.setDirection(oboe::Direction::Output)
        ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
        ->setSharingMode(oboe::SharingMode::Exclusive)
        ->setFormat(oboe::AudioFormat::Float)
        ->setChannelCount(oboe::ChannelCount::Stereo)
        ->setUsage(oboe::Usage::Game)
        ->setCallback(this);
    if (b.openStream(stream) != oboe::Result::OK) return false;
    sr = (float)stream->getSampleRate();
    dbuf.assign((size_t)sr, 0.f); dlen = (int)(sr * .3f); dpos = 0;
    stream->setBufferSizeInFrames(stream->getFramesPerBurst() * bursts);
    return stream->requestStart() == oboe::Result::OK;
}

void AudioEngine::stop() {
    wanted = false;
    if (stream) { stream->stop(); stream->close(); stream.reset(); }
}

void AudioEngine::onErrorAfterClose(oboe::AudioStream *, oboe::Result) {
    // Auriculares conectados/desconectados, etc.: reabrir el stream.
    stream.reset();
    if (wanted) start();
}

float AudioEngine::latencyMs() {
    if (!stream) return -1.f;
    auto r = stream->calculateLatencyMillis();
    return r.error() == oboe::Result::OK ? (float)r.value() : -1.f;
}

void AudioEngine::setBursts(int n) {
    bursts = std::max(1, std::min(4, n));
    if (stream) stream->setBufferSizeInFrames(stream->getFramesPerBurst() * bursts);
}

oboe::DataCallbackResult AudioEngine::onAudioReady(oboe::AudioStream *, void *data, int32_t n) {
    float *out = (float *)data;
    // 1) eventos de la UI
    uint32_t r = rd.load(std::memory_order_relaxed), w = wr.load(std::memory_order_acquire);
    while (r != w) {
        Ev e = ring[r % RN]; r++;
        if (e.type == 1) noteOnI(e.a, e.b, e.v, -1);
        else if (e.type == 2) { for (auto &s : syn) if (s.on && s.id == e.a && s.gate < 0) s.rel = true; }
        else if (e.type == 3) drumI(e.a, e.v);
        else if (e.type == 4) { playing = e.b != 0; if (playing) { curStep = 0; stepLeft = 1; } else stepNow.store(-1); }
    }
    rd.store(r, std::memory_order_release);
    // 2) parametros del bloque
    const float vol = L(0), dmix = L(5) * .8f, sw = L(7) * .33f, bpm = std::max(30.f, L(8));
    const int wave = std::min(3, (int)(L(6) * 4.f)), len = std::max(1, std::min(32, (int)L(9)));
    const float fc = std::min(100.f * std::pow(120.f, L(1)), sr / 6.f);
    const float f = 2.f * std::sin(3.14159265f * fc / sr), q = 1.f / (.5f + L(2) * 14.f);
    const float atkInc = 1.f / ((.003f + L(3) * .6f) * sr), relDec = 1.f / ((.05f + L(4) * 2.f) * sr);
    const float base = sr * 60.f / bpm / 4.f;

    for (int i = 0; i < n; i++) {
        // secuenciador con precision de muestra
        if (playing && --stepLeft <= 0) {
            int s = curStep;
            for (int l = 0; l < 16; l++) if ((pat[l].load(std::memory_order_relaxed) >> s) & 1u) drumI(l, .8f);
            for (int l = 16; l < 32; l++) if ((pat[l].load(std::memory_order_relaxed) >> s) & 1u) noteOnI(100 + l, laneNote[l - 16].load(std::memory_order_relaxed), .8f, (int)(base * .9f));
            stepNow.store(s, std::memory_order_relaxed);
            stepLeft = (int)(base * ((s & 1) ? 1.f - sw : 1.f + sw));
            curStep = (s + 1) % len;
        }
        float s = 0.f;
        for (auto &v : syn) {
            if (!v.on) continue;
            if (v.gate > 0 && --v.gate == 0) v.rel = true;
            if (v.rel) { v.env -= relDec; if (v.env <= 0.f) { v.on = false; continue; } }
            else if (v.env < 1.f) v.env = std::min(1.f, v.env + atkInc);
            v.ph += v.freq / sr; if (v.ph >= 1.f) v.ph -= 1.f;
            float o = wave == 0 ? std::sin(TWO_PI * v.ph) : wave == 1 ? 4.f * std::fabs(v.ph - .5f) - 1.f : wave == 2 ? 2.f * v.ph - 1.f : (v.ph < .5f ? 1.f : -1.f);
            v.low += f * v.band; float high = o - v.low - q * v.band; v.band += f * high;
            s += v.low * v.env * v.vel * .22f;
        }
        for (auto &d : dr) {
            if (!d.on) continue;
            const DP &p = DT[d.type];
            float t = d.n++ / sr, env = std::exp(-p.dec * t);
            if (env < .001f) { d.on = false; continue; }
            float x = 0.f;
            if (p.tone > 0.f) { float fr = p.f1 + (p.f0 - p.f1) * std::exp(-p.pd * t); d.ph += TWO_PI * fr / sr; if (d.ph > TWO_PI) d.ph -= TWO_PI; x += std::sin(d.ph) * p.tone; }
            if (p.noise > 0.f) { float nz = noise(); d.lp += (.9f - .85f * p.hp) * (nz - d.lp); x += (nz - d.lp) * p.noise; }
            s += x * env * d.vel * .6f;
        }
        float dl = dbuf[dpos]; dbuf[dpos] = s + dl * .38f; if (++dpos >= dlen) dpos = 0;
        s = std::tanh((s + dl * dmix) * vol);
        out[2 * i] = out[2 * i + 1] = s;
    }
    return oboe::DataCallbackResult::Continue;
}
