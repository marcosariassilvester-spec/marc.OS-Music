package com.marc.os

import android.graphics.Bitmap
import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.sin

private const val TIN = 2.2f   // las particulas se ensamblan (render)
private const val TOUT = 7.0f  // empieza la desintegracion
private const val TEND = 10f   // fin del splash

private class Parts(
    val n: Int, val hx: FloatArray, val hy: FloatArray, val sx: FloatArray, val sy: FloatArray,
    val d: FloatArray, val ph: FloatArray, val vx: FloatArray, val vy: FloatArray,
    val nx: FloatArray, val g: ByteArray, val size: Float
) {
    val ga = FloatArray(n * 2)
    val gb = FloatArray(n * 2)
}

private fun sm(x: Float): Float { val c = x.coerceIn(0f, 1f); return c * c * (3f - 2f * c) }

/** Dibuja logo + texto en un bitmap y lo convierte en particulas. */
private fun build(w: Int, h: Int): Parts {
    val bw = 640; val bh = 320
    val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
    val cv = android.graphics.Canvas(bmp)
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.color = android.graphics.Color.WHITE
    p.style = Paint.Style.STROKE; p.strokeWidth = 9f
    val path = android.graphics.Path()
    for (k in 0..5) {
        val a = Math.toRadians(60.0 * k - 90.0)
        val x = (320 + 72 * Math.cos(a)).toFloat(); val y = (96 + 72 * Math.sin(a)).toFloat()
        if (k == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }
    path.close(); cv.drawPath(path, p)
    p.style = Paint.Style.FILL
    val hs = floatArrayOf(22f, 44f, 70f, 44f, 22f)
    for (i in 0..4) { val x = 320f + (i - 2) * 17f; cv.drawRect(x - 5f, 96f - hs[i] / 2f, x + 5f, 96f + hs[i] / 2f, p) }
    p.textSize = 104f; p.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD); p.textAlign = Paint.Align.CENTER
    cv.drawText("marc.OS", 320f, 262f, p)
    val px = IntArray(bw * bh); bmp.getPixels(px, 0, bw, 0, 0, bw, bh)
    val pts = ArrayList<Int>()
    var y = 0
    while (y < bh) { var x = 0; while (x < bw) { if ((px[y * bw + x] ushr 24) > 128) pts.add(y * bw + x); x += 3 }; y += 3 }
    val n = pts.size
    val sc = minOf(w * 0.62f / bw, h * 0.78f / bh)
    val ox = (w - bw * sc) / 2f; val oy = (h - bh * sc) / 2f - h * 0.02f
    val rnd = java.util.Random(7)
    fun r() = rnd.nextFloat()
    val hx = FloatArray(n); val hy = FloatArray(n); val sx = FloatArray(n); val sy = FloatArray(n)
    val d = FloatArray(n); val ph = FloatArray(n); val vx = FloatArray(n); val vy = FloatArray(n)
    val nx = FloatArray(n); val g = ByteArray(n)
    for (i in 0 until n) {
        val v = pts[i]; val xx = v % bw; val yy = v / bw
        hx[i] = ox + xx * sc; hy[i] = oy + yy * sc
        sx[i] = -w * 0.2f + r() * w * 1.4f; sy[i] = -h * 0.2f + r() * h * 1.4f
        d[i] = r(); ph[i] = r() * 6.28f
        vx[i] = 150f + r() * 600f; vy[i] = -650f + r() * 730f
        nx[i] = (hx[i] - ox) / (bw * sc)
        g[i] = if (r() < 0.18f) 1 else 0
    }
    return Parts(n, hx, hy, sx, sy, d, ph, vx, vy, nx, g, 3f * sc * 0.95f)
}

@Composable
fun Splash(acc: Color, onDone: () -> Unit) {
    var t by remember { mutableFloatStateOf(0f) }
    var skip by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        val t0 = withFrameNanos { it }
        while (t < TEND) { withFrameNanos { now -> t = if (skip) TEND else (now - t0) / 1e9f } }
        onDone()
    }
    BoxWithConstraints(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { skip = true } }) {
        val wPx = constraints.maxWidth; val hPx = constraints.maxHeight
        val parts = remember(wPx, hPx) { build(wPx, hPx) }
        val paintA = remember { Paint().apply { strokeCap = Paint.Cap.SQUARE; isAntiAlias = false } }
        val paintB = remember { Paint().apply { strokeCap = Paint.Cap.SQUARE; isAntiAlias = false } }
        val bgA = 1f - sm((t - 8.3f) / 1.7f)
        Canvas(Modifier.fillMaxSize()) {
            val W = size.width; val H = size.height
            drawRect(Color(0xFF05060A).copy(alpha = bgA))
            drawCircle(Brush.radialGradient(listOf(acc.copy(alpha = 0.18f * bgA), Color.Transparent), center = center, radius = W * 0.45f), radius = W * 0.45f, center = center)
            val gap = H / 12f
            for (i in 0..12) { val yy = (i * gap + t * 30f) % H; drawLine(acc.copy(alpha = 0.07f * bgA), Offset(0f, yy), Offset(W, yy)) }
            for (i in 0..16) { val xx = i * W / 16f; drawLine(acc.copy(alpha = 0.05f * bgA), Offset(xx, 0f), Offset(xx, H)) }
            if (t < TIN) {
                val sy = t / TIN * H
                drawRect(Brush.verticalGradient(listOf(Color.Transparent, acc.copy(alpha = 0.35f)), startY = sy - 140f, endY = sy), Offset(0f, sy - 140f), Size(W, 140f))
                drawLine(acc, Offset(0f, sy), Offset(W, sy), strokeWidth = 3f)
            }
            val P = parts
            var na = 0; var nb = 0
            for (i in 0 until P.n) {
                var x: Float; var y: Float
                if (t < TIN) {
                    val k = ((t - P.d[i] * 1.3f) / 0.9f).coerceIn(0f, 1f)
                    val e = 1f - (1f - k) * (1f - k) * (1f - k)
                    x = P.sx[i] + (P.hx[i] - P.sx[i]) * e; y = P.sy[i] + (P.hy[i] - P.sy[i]) * e
                } else if (t < TOUT) {
                    x = P.hx[i] + sin(t * 3f + P.ph[i]) * 1.2f; y = P.hy[i] + cos(t * 2.3f + P.ph[i]) * 1.2f
                } else {
                    val q = ((t - TOUT - P.nx[i] * 1.6f - P.d[i] * 0.3f) / 1.1f).coerceIn(0f, 1f)
                    if (q >= 1f) continue
                    x = P.hx[i] + P.vx[i] * q * q; y = P.hy[i] + P.vy[i] * q * q + sin(q * 7f + P.ph[i]) * 18f * q
                }
                if (P.g[i].toInt() == 0) { P.ga[na++] = x; P.ga[na++] = y } else { P.gb[nb++] = x; P.gb[nb++] = y }
            }
            val pa = ((1f - sm((t - 9.3f) / 0.7f)) * 255).toInt()
            paintA.color = acc.toArgb(); paintA.alpha = pa; paintA.strokeWidth = P.size
            paintB.color = Color(0xFFFF2BD6).toArgb(); paintB.alpha = pa; paintB.strokeWidth = P.size
            drawIntoCanvas { c -> c.nativeCanvas.drawPoints(P.ga, 0, na, paintA); c.nativeCanvas.drawPoints(P.gb, 0, nb, paintB) }
        }
        val pct = ((t / TIN).coerceIn(0f, 1f) * 100).toInt()
        Text(
            if (t < TIN) "RENDERIZANDO $pct%" else if (t < TOUT) "MOTOR DE AUDIO OBOE · LISTO" else "INICIANDO INTERFAZ...",
            Modifier.align(Alignment.BottomCenter).padding(22.dp).alpha(bgA),
            color = acc, fontFamily = MONO, fontSize = 12.sp
        )
    }
}
