package com.marc.os

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContent { PadTest() }
    }
    override fun onStart() { super.onStart(); NativeAudio.start() }
    override fun onStop() { super.onStop(); NativeAudio.stop() }
}

private val SCALE = intArrayOf(0, 2, 4, 5, 7, 9, 11)
private fun midi(d: Int) = 48 + (d / 7) * 12 + SCALE[d % 7]

/** Pantalla de prueba (Parte 1): pads 8x8 + secuenciador, para medir la latencia. */
@Composable
fun PadTest() {
    var lat by remember { mutableStateOf(-1f) }
    var step by remember { mutableStateOf(-1) }
    var playing by remember { mutableStateOf(false) }
    var lit by remember { mutableStateOf(setOf<Int>()) }
    LaunchedEffect(Unit) {
        for (l in 0 until 16) NativeAudio.setLaneNote(l, midi(l))
        listOf(0, 4, 8, 12).forEach { NativeAudio.setCell(0, it, true) }
        listOf(4, 12).forEach { NativeAudio.setCell(2, it, true) }
        (0 until 16 step 2).forEach { NativeAudio.setCell(4, it, true) }
        listOf(0, 3, 8, 11).forEach { NativeAudio.setCell(16, it, true) }
        while (true) { lat = NativeAudio.getLatencyMs(); step = NativeAudio.getStep(); delay(100) }
    }
    Row(Modifier.fillMaxSize().background(Color(0xFF05060A)).safeDrawingPadding().padding(8.dp)) {
        Canvas(
            Modifier.fillMaxHeight().aspectRatio(1f).pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        val ev = awaitPointerEvent(PointerEventPass.Initial)
                        ev.changes.forEach { c ->
                            val id = (c.id.value % 64).toInt()
                            val col = (c.position.x / size.width * 8).toInt().coerceIn(0, 7)
                            val fy = (c.position.y / size.height * 8)
                            val r = 7 - fy.toInt().coerceIn(0, 7)
                            val pad = r * 8 + col
                            if (c.pressed && !c.previousPressed) {
                                val vel = (.6f + .4f * (1f - (fy - fy.toInt()))).coerceIn(.2f, 1f)
                                if (r < 4 && col < 4) NativeAudio.drum(r * 4 + col, vel)
                                else NativeAudio.noteOn(id, midi(col + r * 3), vel)
                                lit = lit + pad
                            } else if (!c.pressed && c.previousPressed) {
                                NativeAudio.noteOff(id)
                                lit = lit - pad
                            }
                            c.consume()
                        }
                    }
                }
            }
        ) {
            val cs = size.width / 8f
            for (vr in 0..7) for (c in 0..7) {
                val r = 7 - vr
                val on = (r * 8 + c) in lit
                val base = if (r < 4 && c < 4) Color(0xFF2A0F3D) else Color(0xFF0E1A24)
                val neon = if (r < 4 && c < 4) Color(0xFFFF2BD6) else Color(0xFF00F5FF)
                val tl = Offset(c * cs + 3f, vr * cs + 3f); val sz = Size(cs - 6f, cs - 6f)
                drawRoundRect(if (on) neon else base, tl, sz, CornerRadius(8f))
                drawRoundRect(neon.copy(alpha = if (on) 1f else .45f), tl, sz, CornerRadius(8f), style = Stroke(2f))
            }
        }
        Column(Modifier.padding(start = 12.dp)) {
            Text("marc.OS · parte 1", color = Color(0xFF00F5FF), fontFamily = FontFamily.Monospace)
            Text("latencia de salida: " + (if (lat < 0) "--" else "%.1f ms".format(lat)), color = Color(0xFFFF2BD6), fontFamily = FontFamily.Monospace)
            Text("paso: $step", color = Color.White, fontFamily = FontFamily.Monospace)
            Spacer(Modifier.height(8.dp))
            Button(onClick = { playing = !playing; NativeAudio.setPlaying(playing) }) { Text(if (playing) "■ STOP" else "▶ PLAY") }
        }
    }
}
