# marc.OS · Parte 1 (motor de audio de baja latencia)
1. Android Studio (Koala o más nuevo) > Open > carpeta `marcOS`. Sync Gradle (instala NDK y CMake 3.22.1 si lo pide).
2. Ejecuta en un MÓVIL REAL (el emulador tiene mala latencia). Mejor con cable o altavoz; los auriculares Bluetooth añaden 100+ ms.
3. Prueba: abajo-izq. 4x4 = batería, resto = notas, PLAY = secuenciador. Arriba a la derecha se muestra la latencia de salida.
Siguiente: pads/faders completos (modos), splash marc.OS con partículas, menús ciberpunk y configuración.
