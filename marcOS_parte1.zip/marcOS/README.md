# marc.OS · Parte 2
Interfaz completa: splash "marc.OS" (10 s, toca para saltar), 4 modos, faders, menús y configuración.
Compilar: sube marcOS_parte1.zip (mismo nombre) al repositorio de GitHub y espera el APK en Releases.
